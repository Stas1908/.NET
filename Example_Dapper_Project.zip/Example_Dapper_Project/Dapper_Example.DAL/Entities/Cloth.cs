﻿
namespace Dapper_Example.DAL
{
    public class Cloth
    {
        public int id { get; set; }
        public string? name { get; set; }
        public string? size { get; set; }
        public string? type { get; set; }

    }
}
