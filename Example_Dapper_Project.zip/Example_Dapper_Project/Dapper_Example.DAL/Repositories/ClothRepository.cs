﻿using Dapper;
using Dapper_Example.DAL.Repositories.Interfaces;
using System.Data;
using System.Data.SqlClient;

namespace Dapper_Example.DAL.Repositories
{
    public class ClothRepository : GenericRepository<Cloth>, IClothRepository
    {
        protected SqlConnection _sqlConnection;
        protected IDbTransaction _dbTransaction;

        public ClothRepository(SqlConnection sqlConnection, IDbTransaction dbtransaction) : base(sqlConnection, dbtransaction, "Cloth")
        {
            _sqlConnection = sqlConnection;
            _dbTransaction = dbtransaction;

        }

        public async Task<int> Create(Cloth cloth)
        {
            return await _sqlConnection.ExecuteAsync("insert into Cloth(name, size, type) values(@Name, @Size, @Type)", cloth,transaction: _dbTransaction);
        }

        public async Task<int> Update(Cloth cloth)
        {
            return await _sqlConnection.ExecuteAsync("update Cloth set name=@Name, size=@Size, type=@Type where id=@Id", cloth, transaction: _dbTransaction);
        }
    }
}
