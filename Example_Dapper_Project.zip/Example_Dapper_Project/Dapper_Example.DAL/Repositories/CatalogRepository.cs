﻿using Dapper;
using Dapper_Example.DAL.Repositories.Interfaces;
using System.Data;
using System.Data.SqlClient;
using System.Transactions;

namespace Dapper_Example.DAL.Repositories
{
    public class CatalogRepository : GenericRepository<Catalog>, ICatalogRepository
    {
        protected SqlConnection _sqlConnection;
        protected IDbTransaction _dbTransaction;
        public CatalogRepository(SqlConnection sqlConnection, IDbTransaction dbtransaction) : base(sqlConnection, dbtransaction, "Catalog")
        {
            _sqlConnection = sqlConnection;
            _dbTransaction = dbtransaction;
        }

        public void Create(Catalog catalog)
        {
            string sqlExpression = "INSERT INTO Catalog (cloth_id, price) VALUES (@cloth_id, @price);";
            using (_dbTransaction)
            {
                try
                {
                    //_sqlConnection.Open();
                    SqlCommand sqlCommand = new SqlCommand(sqlExpression, _sqlConnection, (SqlTransaction)_dbTransaction);
                    sqlCommand.Parameters.Add(new SqlParameter("@cloth_id", catalog.cloth_id));
                    sqlCommand.Parameters.Add(new SqlParameter("@price", catalog.price));
                    sqlCommand.ExecuteNonQuery();
                    _dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    _dbTransaction.Rollback();
                    System.Console.WriteLine(ex.ToString());
                }
                finally
                {
                    _sqlConnection.Close();
                }
            }
        }
        public void Update(Catalog catalog)
        {
            string sqlExpression = "EXEC UpdateCatalog @id = @idElem, @clothId = @cloth_id, @NewPrice = @price;";
            using (_dbTransaction)
            {
                try
                {
                    //_sqlConnection.Open();
                    SqlCommand sqlCommand = new SqlCommand(sqlExpression, _sqlConnection, (SqlTransaction)_dbTransaction);
                    sqlCommand.Parameters.Add(new SqlParameter("@idElem", catalog.id));
                    sqlCommand.Parameters.Add(new SqlParameter("@cloth_id", catalog.cloth_id));
                    sqlCommand.Parameters.Add(new SqlParameter("@price", catalog.price));
                    sqlCommand.ExecuteNonQuery();
                    _dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    _dbTransaction.Rollback();
                }
                finally
                {
                    _sqlConnection.Close();
                }
            }
        }
    }
}
