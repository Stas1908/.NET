﻿namespace Dapper_Example.DAL.Repositories.Interfaces
{
    public interface IGenericRepository<T>
    {
        Task<IEnumerable<T>> GetAll();
        Task Delete(int id);
        Task<T> Get(int id);
        //Task<int> AddRange(IEnumerable<T> list);
        //Task Replace(T t);
        //Task<int> Add(T t);
    }
}
