﻿using Dapper_Example.DAL;

namespace Dapper_Example.DAL.Repositories.Interfaces
{
    public interface ICatalogRepository : IGenericRepository<Catalog>
    {
        void Create(Catalog catalog);
        void Update(Catalog catalog);
    }
}
