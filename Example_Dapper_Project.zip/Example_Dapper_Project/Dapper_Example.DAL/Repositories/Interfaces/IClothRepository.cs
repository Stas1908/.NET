﻿namespace Dapper_Example.DAL.Repositories.Interfaces
{
    public interface IClothRepository : IGenericRepository<Cloth>
    {
        Task<int> Create(Cloth cloth);
        Task<int> Update(Cloth cloth);
    }
}
