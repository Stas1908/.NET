﻿namespace Dapper_Example.DAL.Repositories.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IClothRepository _clothRepository { get; }

        ICatalogRepository _catalogRepository { get; }
        void Commit();
        void Dispose();
    }
}
