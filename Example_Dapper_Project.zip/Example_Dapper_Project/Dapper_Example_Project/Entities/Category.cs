﻿namespace Dapper_Example_Project.Entities
{
    public class Category : BaseEntity
    {
        public String Name { get; set; }

        public String Properties { get; set; }
    }
}
