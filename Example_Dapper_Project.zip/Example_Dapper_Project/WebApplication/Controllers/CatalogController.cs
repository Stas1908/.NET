﻿using ConsoleApplicationExample.Services.Interfaces;
using Dapper_Example.DAL;
using Dapper_Example.DAL.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;


namespace Dapper_Example_Project.Controllers
{
    [Route("/api/catalog")]
    [ApiController]
    public class CatalogController : ControllerBase
    {
        private ICatalogService _catalogService;
        public CatalogController( ICatalogService catalogService)
        {
            _catalogService = catalogService;
        }

        [HttpGet]
        public Task<IEnumerable<Catalog>> GetAll() => _catalogService.GetAll();

        [HttpGet("{id}")]
        public Task<ActionResult<Catalog>> GetById(int id) => _catalogService.GetById(id);
        


        [HttpPost]
        public async void Create(Catalog category)
        {
            _catalogService.Create(category);
          
        }

        [HttpPut]
        public async void Update (Catalog catalog)
        {
            _catalogService.Update(catalog);

        }

        [HttpDelete]
        public  Task<bool> Delete (int id)=>_catalogService.Delete(id);

    }
}
