﻿using ConsoleApplicationExample.Services.Interfaces;
using Dapper_Example.DAL;
using Dapper_Example.DAL.Repositories;
using Dapper_Example.DAL.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.InteropServices;


namespace restapi.Controllers
{
    [Route("api/cloth")]
    [ApiController]
    public class ClothController : ControllerBase
    {

        private IClothService _clothService;
        public ClothController(IClothService clothService)
        {
            _clothService = clothService;
        }
        [HttpGet]
        public Task<IEnumerable<Cloth>> GetAll() => _clothService.GetAll();
        [HttpGet("{id}")]
        public Task<ActionResult<Cloth>> GetById(int id) => _clothService.GetById(id);
    
        [HttpPost]
        public Task<int> Create(Cloth cloth) => _clothService.Create(cloth);

        [HttpPut]
        public  Task<int> Update(Cloth cloth) => _clothService.Update(cloth);

        [HttpDelete("{id}")]
        public Task<bool> Delete(int id) => _clothService.Delete(id);

    }
}

