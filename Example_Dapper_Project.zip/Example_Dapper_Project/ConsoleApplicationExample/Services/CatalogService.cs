﻿using ConsoleApplicationExample.Services.Interfaces;
using Dapper_Example.DAL;
using Dapper_Example.DAL.Repositories.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplicationExample.Services
{
    public class CatalogService : ICatalogService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<ClothService> _logger;
        public CatalogService(ILogger<ClothService> logger, IUnitOfWork uow)
        {
            _unitOfWork = uow;
            _logger = logger;
        }

        public void Create(Catalog catalog)
        {
            _unitOfWork._catalogRepository.Create(catalog);
        }

        public async Task<bool> Delete(int id)
        {
            var productEntity = await _unitOfWork._catalogRepository.Get(id);
            if (productEntity == null)
            {
                return false;  
            }
            await _unitOfWork._catalogRepository.Delete(id);
            _unitOfWork.Commit();
            return true;
        }

        public async Task<IEnumerable<Catalog>> GetAll()
        {
            try
            {
                var results = await _unitOfWork._catalogRepository.GetAll();
                _unitOfWork.Commit();
                _logger.LogInformation($"Returned all categories from database.");
                return results;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Transaction Failed! Something went wrong inside GetCategoryAsync() action: {ex.Message}");
                return null;
            }
        }

        public async Task<ActionResult<Catalog>> GetById(int id)
        {
            try
            {
                var result = await _unitOfWork._catalogRepository.Get(id);
                _unitOfWork.Commit();
                if (result == null)
                {
                    _logger.LogError($"Category with id: {id}, hasn't been found in db.");
                    return null;
                }
                else
                {
                    _logger.LogInformation($"Returned category with id: {id}");
                    return result;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside GetAsync action: {ex.Message}");
                return null;
            }

        }

        public void Update(Catalog catalog)
        {
            _unitOfWork._catalogRepository.Update(catalog);
        }
    }
}
