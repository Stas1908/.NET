﻿using Dapper_Example.DAL;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplicationExample.Services.Interfaces
{
    public interface IClothService
    {
        Task<IEnumerable<Cloth>> GetAll();
        Task<ActionResult<Cloth>> GetById(int id);
        Task<int> Create(Cloth cloth);
        Task<int> Update(Cloth cloth);
        Task<bool> Delete(int id);
    }
}
