﻿using Dapper_Example.DAL;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplicationExample.Services.Interfaces
{
    public interface ICatalogService
    {
        Task<IEnumerable<Catalog>> GetAll();
        Task<ActionResult<Catalog>> GetById(int id);
        void Create(Catalog catalog);
        void Update(Catalog catalog);
        Task<bool> Delete(int id);
    }
}
