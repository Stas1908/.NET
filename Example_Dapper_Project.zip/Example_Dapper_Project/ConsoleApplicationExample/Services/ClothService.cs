﻿using ConsoleApplicationExample.Services.Interfaces;
using Dapper_Example.DAL;
using Dapper_Example.DAL.Repositories;
using Dapper_Example.DAL.Repositories.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplicationExample.Services
{
    public class ClothService : IClothService
    {
        private readonly IUnitOfWork _unitofWork;
        private readonly ILogger<ClothService> _logger;
        public ClothService(ILogger<ClothService> logger, IUnitOfWork uow)
        {
            _logger = logger;
            _unitofWork = uow;
        }

        public async Task<int> Create(Cloth cloth)
        {
            try
            {
                await _unitofWork._clothRepository.Create(cloth);
                _unitofWork.Commit();
                return 1;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside Create action: {ex.Message}");
                return 0;
            }
        }

        public async Task<bool> Delete(int id)
        {
            //try
            //{
            //    var ProductEntity = await _unitofWork._clothRepository.Get(id);
            //    if (ProductEntity == null)
            //    {
            //        _logger.LogError($"Product with id: {id}, hasn't been found in db.");
            //        return (ActionResult)null;
            //    }
            //    await _unitofWork._clothRepository.Delete(id);
            //    _unitofWork.Commit();
            //    return (ActionResult)await GetAll();
            //}
            //catch (Exception ex)
            //{
            //    _logger.LogError($"Something went wrong inside Product action: {ex.Message}");
            //    return (ActionResult)null;
            //}
            var productEntity =  await _unitofWork._clothRepository.Get(id);
            if (productEntity == null)
            {
                return false; // Повернути false, якщо продукт не знайдено
            }

            await _unitofWork._clothRepository.Delete(id);
            _unitofWork.Commit();
            return true;
        }

        public async Task<IEnumerable<Cloth>> GetAll()
        {
            try
            {
                var results = await _unitofWork._clothRepository.GetAll();
                _unitofWork.Commit();
                _logger.LogInformation($"Returned all products from database.");
                return (results);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Transaction Failed! Something went wrong inside GetAllProductsAsync() action: {ex.Message}");
                return null;
            }
        }

        public async Task<ActionResult<Cloth>> GetById(int id)
        {
            try
            {
                var result = await _unitofWork._clothRepository.Get(id);
                _unitofWork.Commit();
                if (result == null)
                {
                    _logger.LogError($"Cloth with id: {id}, hasn't been found in db.");
                    return null;
                }
                else
                {
                    _logger.LogInformation($"Returned cloth with id: {id}");
                    return result;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside GetByIdAsync() action: {ex.Message}");
                return null;
            }
        }

        public async Task<int> Update(Cloth cloth)
        {
            try
            {
                await _unitofWork._clothRepository.Update(cloth);
                _unitofWork.Commit();
                return 1;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside Create action: {ex.Message}");
                return 0;
            }
        }
    }
}
